import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

void main() {
  group('Phase 1 Firestore rules coverage', () {
    late String rules;

    setUpAll(() {
      rules = File('firestore.rules').readAsStringSync();
    });

    test('cross-business branch access blocked', () {
      expect(
        rules.contains('request.resource.data.businessId == businessId'),
        isTrue,
      );
      expect(rules.contains('resource.data.businessId == businessId'), isTrue);
    });

    test('unauthorized branch writes blocked', () {
      expect(
        rules.contains("hasBusinessPermission(businessId, 'manage_branches')"),
        isTrue,
      );
      expect(rules.contains('match /branches/{branchId}'), isTrue);
    });

    test('staff self-assignment blocked', () {
      expect(rules.contains('memberId != request.auth.uid'), isTrue);
      expect(
        rules.contains("request.resource.data.get('assignedBranchIds', []) == resource.data.get('assignedBranchIds', [])"),
        isTrue,
      );
      expect(
        rules.contains("request.resource.data.get('allBranchesAccess', false) == resource.data.get('allBranchesAccess', false)"),
        isTrue,
      );
    });

    test('permissive empty-branch auto-grant removed', () {
      expect(rules.contains("memberData(businessId).get('assignedBranchIds', []).size() == 0"), isTrue);
      expect(rules.contains("&& normalized == 'main'"), isTrue);
      expect(rules.contains('effectiveBranchId(data)'), isTrue);
    });
  });
}
